self.addEventListener('install', e => {
  e.waitUntil(
    caches.open('inventario-cache').then(cache => {
      return cache.addAll([
        './',
        './index.html',
        './manifest.json',
        './icon-192.png',
        './icon-512.png',
        './libs/jspdf.umd.min.js',
        './libs/jspdf.plugin.autotable.js',
        './libs/xlsx.full.min.js'
      ]);
    })
  );
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(resp => resp || fetch(e.request))
  );
});


